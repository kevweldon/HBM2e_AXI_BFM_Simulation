---------------------
; Table of Contents ;
---------------------
  1. About this file


------------------------
;   1. About this file ;
------------------------

   This is the readme file for the 'hbm_arch_fp' IP.
   This will eventually provide a high-level overview of the IP, but for now this is a placeholder.
   
   This file was auto-generated.


